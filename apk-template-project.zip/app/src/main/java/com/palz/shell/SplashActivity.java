package com.palz.shell;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.VideoView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class SplashActivity extends Activity {
    private boolean went = false;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Config.load(this);
        Config.applyOrientation(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Config.color(Config.bg, 0xFF0A0A0A));
        setContentView(root);
        root.setOnClickListener(v -> next());

        if ("video".equals(Config.splash)) {
            playVideo(root);
        } else if ("image".equals(Config.splash)) {
            showImage(root);
        } else {
            next();
        }
    }

    private void showImage(FrameLayout root) {
        try {
            InputStream in = getAssets().open("palz/splash.png");
            Bitmap bmp = BitmapFactory.decodeStream(in);
            in.close();
            ImageView image = new ImageView(this);
            image.setImageBitmap(bmp);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            root.addView(image, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            handler.postDelayed(this::next, Config.splashMs);
        } catch (Exception e) {
            next();
        }
    }

    private void playVideo(final FrameLayout root) {
        final File f = new File(getCacheDir(), "palz-splash.mp4");
        new Thread(() -> {
            boolean ok = false;
            try {
                InputStream in = getAssets().open("palz/splash.mp4");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
                ok = true;
            } catch (Exception ignored) {
            }
            final boolean done = ok;
            runOnUiThread(() -> {
                if (went || isFinishing()) return;
                if (!done) {
                    next();
                    return;
                }
                VideoView video = new VideoView(this);
                root.addView(video, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, android.view.Gravity.CENTER));
                video.setVideoPath(f.getAbsolutePath());
                video.setOnCompletionListener(mp -> next());
                video.setOnErrorListener((mp, what, extra) -> {
                    next();
                    return true;
                });
                video.start();
                handler.postDelayed(this::next, 90000);
            });
        }).start();
    }

    private void next() {
        if (went) return;
        went = true;
        handler.removeCallbacksAndMessages(null);
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
