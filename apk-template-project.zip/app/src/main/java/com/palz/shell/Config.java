package com.palz.shell;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Color;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Membaca assets/palz/config.json. File itu diganti oleh web PALZzz untuk tiap aplikasi. */
final class Config {
    static String start = "https://example.com";
    static boolean local = false;
    static boolean fullscreen = false;
    static boolean external = true;
    static boolean keepOn = false;
    static String splash = "none";
    static int splashMs = 2000;
    static String bg = "#0A0A0A";
    static String status = "#4C1D95";
    static String ori = "auto";

    private static boolean loaded = false;

    private Config() {}

    static synchronized void load(Context c) {
        if (loaded) return;
        loaded = true;
        try {
            InputStream in = c.getAssets().open("palz/config.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            start = j.optString("start", start);
            local = j.optBoolean("local", local);
            fullscreen = j.optBoolean("fs", fullscreen);
            external = j.optBoolean("ext", external);
            keepOn = j.optBoolean("keep", keepOn);
            splash = j.optString("splash", splash);
            splashMs = Math.max(500, Math.min(10000, j.optInt("ms", splashMs)));
            bg = j.optString("bg", bg);
            status = j.optString("status", status);
            ori = j.optString("ori", ori);
        } catch (Exception ignored) {
        }
        if (local) start = "file:///android_asset/palz/www/index.html";
    }

    static int color(String s, int fallback) {
        try {
            return Color.parseColor(s);
        } catch (Exception e) {
            return fallback;
        }
    }

    static void applyOrientation(Activity a) {
        if ("portrait".equals(ori)) {
            a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if ("landscape".equals(ori)) {
            a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
    }
}
